
function get(data) {
    console.log(data);
}